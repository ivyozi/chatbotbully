<?php
require 'vendor/autoload.php';

use TextBlob\TextBlob;

// Input text
$text = "Natural language processing is a field of artificial intelligence.";

// Create a TextBlob instance
$blob = new TextBlob($text);

// Tokenize the text
$words = $blob->words;
echo "Tokens: " . implode(', ', $words) . PHP_EOL;

// Perform part-of-speech tagging
$tags = $blob->tags;
echo "Part-of-Speech Tags: " . json_encode($tags) . PHP_EOL;
?>
